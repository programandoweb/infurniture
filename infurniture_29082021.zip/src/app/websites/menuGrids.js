const App=()=>{
  return  <div className="container-fluid">

              <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="collapse navbar-collapse" id="navbarNav">
                  <ul className="navbar-nav">
                    <li className="nav-item active">
                      <a className="nav-link text-success" href="#">Componentes <span className="sr-only">(current)</span></a>
                    </li>
                    <li className="nav-item">
                      <a className="nav-link" href="#">Container</a>
                    </li>
                    <li className="nav-item">
                      <a className="nav-link" href="#">Filas</a>
                    </li>
                    <li className="nav-item">
                      <a className="nav-link" href="#">Columna</a>
                    </li>
                  </ul>
                </div>
                </nav>

          </div>
}

export default App
