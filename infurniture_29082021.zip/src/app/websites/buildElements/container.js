const App=(props)=>{

  const onClick=()=>{
    
  }

  return  <div className="btn btn-primary mr-1" onClick={onClick}>{props.title}</div>

}
export default App
