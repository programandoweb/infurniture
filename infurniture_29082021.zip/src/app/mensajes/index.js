import React,{useState,useEffect} from 'react';

const App=()=>{
  return <div className="container">BARRA MENSAJES</div>
}

export default App
