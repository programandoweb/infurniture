const App=()=>{
  return  <footer className="pt-5 pb-3 mb-3 text-center color-gray d-none">
            Desarrollo y programación colaborativo ProgramandoWeb & Claudio Gallego
          </footer>
}
export default App
